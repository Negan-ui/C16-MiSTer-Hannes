#!/usr/bin/env python3
"""Model of the integrated wired-AND bus, not HDL simulation."""
from pathlib import Path
p=Path(__file__).resolve().parents[1]
def cassette(a,enabled,sense,adc):
    selected=(a==0xfd10) if enabled else (a>>4==0xfd1)
    return 255 if not selected or (sense and not adc) else 251
n=0
for en in (0,1):
 for sense in (0,1):
  for adc in (0,1):
   for a in range(65536):
    expected=251 if (a in (range(0xfd10,0xfd11) if en else range(0xfd10,0xfd20))) and (adc or not sense) else 255
    assert cassette(a,en,sense,adc)==expected; n+=1
   if en:
    for v in range(256):
     assert (v|60)&cassette(0xfd16,en,sense,adc)==v|60; n+=1
assert (255 & cassette(0xfd16,False,0,0))==251
assert 'hannes_cassette_decode cassette_decode' in (p/'C16.sv').read_text()
assert '.data_out(cass_dout)' in (p/'C16.sv').read_text()
assert "addr == 16'hfd10" in (p/'rtl/hannes256.v').read_text()
print(f'PASS: {n:,} cassette decode and FD16 bus-model checks; old conflict reproduced; HDL simulation not performed.')
