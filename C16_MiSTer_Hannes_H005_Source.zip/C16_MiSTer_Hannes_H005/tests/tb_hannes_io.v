`timescale 1ns / 1ps
module tb_hannes_io;
reg clk=0, reset=1, enabled=0, cpu=1, mux=1, rnw=1, sense=0, adc=0;
reg [15:0] addr=0;
reg [7:0] din=0;
wire [7:0] reg_q, cass_q;
wire [7:0] bus_q = reg_q & cass_q;
wire [1:0] bank;
integer e,s,t,a,v,n=0;
reg [7:0] expected_cass;
always #5 clk=~clk;
hannes256 ctl(clk,reset,enabled,cpu,mux,rnw,addr,din,reg_q,bank);
hannes_cassette_decode dec(enabled,addr,sense,adc,cass_q);
task tick; begin @(posedge clk); #1; end endtask
task wr(input [7:0] value); begin
    addr=16'hfd16; din=value; rnw=0; mux=1; tick;
    mux=0; tick; mux=1; rnw=1; tick;
end endtask
initial begin
    tick; reset=0;
    for(e=0;e<2;e=e+1) begin
        enabled=e; tick;
        for(s=0;s<2;s=s+1) for(t=0;t<2;t=t+1) begin
            sense=s; adc=t;
            for(a=0;a<65536;a=a+1) begin
                addr=a; #1;
                expected_cass=((e ? a==16'hfd10 : (a>=16'hfd10 && a<=16'hfd1f)) && (t || !s)) ? 8'hfb : 8'hff;
                if(cass_q!==expected_cass) $fatal(1,"cassette decode %h mode %d",a,e);
                n=n+1;
            end
            if(e) for(v=0;v<256;v=v+1) begin
                wr(v); if(bus_q!==(v[7:0]|8'h3c)) $fatal(1,"FD16 contention value %h sense %d adc %d",v,s,t);
                n=n+1;
            end
        end
    end
    $display("PASS: %0d cassette/Hannes wired-AND checks",n); $finish;
end
endmodule
