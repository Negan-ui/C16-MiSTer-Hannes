#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
iverilog -g2012 -s tb_hannes256 -o "$tmp/hannes" rtl/hannes256.v tests/tb_hannes256.v
vvp "$tmp/hannes"
iverilog -g2012 -s tb_hannes_ram -o "$tmp/ram" rtl/hannes256.v rtl/hannes_ram.v tests/gen_dpram_model.v tests/tb_hannes_ram.v
vvp "$tmp/ram"
iverilog -g2012 -s tb_hannes_io -o "$tmp/io" rtl/hannes256.v tests/tb_hannes_io.v
vvp "$tmp/io"
iverilog -g2012 -s tb_hannes_exhaustive -o "$tmp/exhaustive" rtl/hannes256.v tests/tb_hannes_exhaustive.v
vvp "$tmp/exhaustive"
