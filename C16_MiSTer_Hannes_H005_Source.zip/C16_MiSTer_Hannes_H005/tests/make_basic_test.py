#!/usr/bin/env python3
"""Tokenize this small BASIC 3.5 diagnostic using the shared BASIC V2 tokens."""
from pathlib import Path
import re, struct
p = Path(__file__).parent
TOKENS = {'END':0x80,'FOR':0x81,'NEXT':0x82,'IF':0x8b,'POKE':0x97,'PRINT':0x99,'TO':0xa4,'THEN':0xa7,'+':0xaa,'OR':0xb0,'>':0xb1,'=':0xb2,'<':0xb3,'PEEK':0xc2}
pat = re.compile('|'.join(re.escape(k) for k in sorted(TOKENS,key=len,reverse=True)))
word = lambda v: struct.pack('<H',v)
addr=0x1001
out=bytearray(word(addr))
for line in (p/'hannes_bank_test.bas').read_text().splitlines():
    n, src=line.split(' ',1)
    data=bytearray()
    quoted=False
    while src:
        if src[0]=='"':
            quoted=not quoted
        m=None if quoted else pat.match(src)
        if m:
            data.append(TOKENS[m.group()]); src=src[len(m.group()):]
        else:
            data.append(ord(src[0])); src=src[1:]
    addr+=5+len(data)
    out+=word(addr)+word(int(n))+data+b'\x00'
out+=b'\x00\x00'
(p/'hannes_bank_test.prg').write_bytes(out)
# Verify line link chain and final zero pointer.
pos=2
while pos<len(out)-2:
    nxt=int.from_bytes(out[pos:pos+2],'little')
    off=nxt-0x1001+2
    assert off>pos+4 and out[off-1]==0
    pos=off
assert out[pos:]==b'\x00\x00'
print(f'BASIC PRG: {len(out)} bytes; linked line addresses verified')
