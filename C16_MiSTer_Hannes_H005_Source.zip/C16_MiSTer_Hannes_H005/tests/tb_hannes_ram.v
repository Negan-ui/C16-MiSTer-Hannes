`timescale 1ns / 1ps
module tb_hannes_ram;
    reg clk=0, reset=1, enabled=1, cpu=1, mux=1, rnw=1;
    reg [15:0] addr=0, load_addr=0;
    reg [7:0] din=0, load_data=0;
    reg we=0, cs=0, load_we=0;
    wire [7:0] reg_q, q;
    wire [1:0] bank;
    integer b,a,p,checks=0;
    always #5 clk=~clk;
    hannes256 ctl(clk,reset,enabled,cpu,mux,rnw,addr,din,reg_q,bank);
    hannes_ram ram(clk,bank,addr,din,we,cs,q,load_addr,load_data,load_we);
    task tick; begin @(posedge clk); #1; end endtask
    task select_bank(input [7:0] v);
        begin cpu=1; addr=16'hfd16; din=v; rnw=0; mux=1; cs=0; tick;
              mux=0; tick; mux=1; rnw=1; tick;
              if(reg_q !== (v|8'h3c)) $fatal(1,"register readback"); end
    endtask
    function [7:0] pattern(input integer bank_num, address, pass);
        pattern=(pass ? (address>>8) : address) ^ (bank_num*53);
    endfunction
    task write_byte(input [15:0] a, input [7:0] v);
        begin addr=a; din=v; cs=1; we=1; tick; we=0; end
    endtask
    task read_byte(input [15:0] a, input [7:0] v);
        begin addr=a; cs=1; we=0; tick; checks=checks+1;
            if(q!==v) $fatal(1,"RAM mismatch %h bank %d got %h expected %h",a,bank,q,v); end
    endtask
    initial begin
        tick; reset=0;
        // First test every switchable physical address using two distinct passes.
        // Write all banks before reading any, to reveal bank and address aliasing.
        for(p=0;p<2;p=p+1) begin
            for(b=0;b<4;b=b+1) begin
                select_bank(8'h7c|b);
                for(a=4096;a<65536;a=a+1) write_byte(a,pattern(b,a,p));
            end
            for(b=0;b<4;b=b+1) begin
                select_bank(8'h7c|b);
                for(a=4096;a<65536;a=a+1) read_byte(a,pattern(b,a,p));
            end
        end
        // Shared region, both switch boundaries, and TED bank override.
        select_bank(8'hff); write_byte(16'h0200,8'h55);
        for(b=0;b<4;b=b+1) begin
            select_bank(8'hfc|b); read_byte(16'h0200,8'h55);
            read_byte(16'h1000,pattern(3,4096,1));
            read_byte(16'h3fff,pattern(3,16383,1));
            read_byte(16'h4000,pattern(b,16384,1));
            cpu=0; read_byte(16'h4000,pattern(b,16384,1));
            select_bank(8'hbc|b); cpu=0;
            read_byte(16'h4000,pattern(3,16384,1));
            cpu=1; read_byte(16'h4000,pattern(b,16384,1));
        end
        // Loader must write only standard bank, even during alternate bank selection.
        select_bank(8'hfc); load_addr=16'h5000; load_data=8'hc7; load_we=1; tick; load_we=0;
        read_byte(16'h5000,pattern(0,20480,1));
        select_bank(8'hff); read_byte(16'h5000,8'hc7);
        cs=0; #1; if(q!==8'hff) $fatal(1,"inactive RAM must be neutral");
        select_bank(8'h7c); reset=1; tick; reset=0;
        read_byte(16'h5000,8'hc7);
        enabled=0; tick; read_byte(16'h5000,8'hc7);
        $display("PASS: %0d RAM read checks; full bank sweeps, TED, loader, reset",checks);
        $finish;
    end
endmodule
