`timescale 1ns/1ps
module tb_hannes_ted_bus;
 parameter [1:0] TVMODE=2'b01;
 reg clk_sys=0, reset=1, hannes_enabled=1; always #5 clk_sys=~clk_sys;
 wire [15:0] c16_addr; wire [7:0] c16_dout; wire c16_rnw,c16_mux,c16_ras,c16_cas,cs0,cs1;
 reg [15:0] dl_addr=0; reg [7:0] dl_data=0; reg dl_wr=0,cass_sense=0,tape_adc_act=0;
 `include "h005_glue.vh"
 wire [7:0] c16_din=ram_dout & cass_dout & ((!cs0 || !cs1)?8'ha5:8'hff);
 C16 dut(.CLK28(clk_sys),.RESET(reset),.WAIT(1'b0),.tvmode(TVMODE),.wide(1'b0),.RnW(c16_rnw),.ADDR(c16_addr),.hannes_enabled(hannes_enabled),.ram_bank(c16_ram_bank),.DIN(c16_din),.DOUT(c16_dout),.MUX(c16_mux),.RAS(c16_ras),.CAS(c16_cas),.CS0(cs0),.CS1(cs1),.cass_in(1'b1),.cass_aud(1'b0),.JOY0(5'b0),.JOY1(5'b0),.ps2_key(11'b0),.IEC_DATAIN(1'b1),.IEC_CLKIN(1'b1),.sid_enabled(1'b0),.sid_ver(2'b0),.sid_cfg(4'b0),.sid_filter(2'b0),.sid_fc_off_l(13'b0),.sid_fc_off_r(13'b0),.sid_digifix(1'b0),.sid_mode(1'b0),.sid_c64(1'b0),.sid_ld_addr(12'b0),.sid_ld_data(16'b0),.sid_ld_wr(1'b0));
 reg [7:0] refmem[0:262143]; reg [7:0] refreg=8'hff;
 integer reads=0,writes=0,bankwrites=0,tedreads=0,tedextra=0,tedbase=0,romreads=0,ignored=0,i,b,p; reg monitor=0;
 function [1:0] eb(input [15:0] a,input own);
  eb=(!hannes_enabled || a<(refreg[7]?16'h4000:16'h1000) || (!own&&!refreg[6]))?3:refreg[1:0];
 endfunction
 task cycle(input [15:0] a,input wr,input [7:0] v,input [7:0] exp);
 begin
  @(negedge clk_sys); while(dut.mos8360.phicounter!==4'd2 || dut.aec!==1'b1) @(negedge clk_sys);
  dut.cpu.cpu.stimulus_addr=a; dut.cpu.cpu.stimulus_data=v; dut.cpu.cpu.stimulus_read=!wr;
  while(dut.mos8360.phicounter!==4'd15) @(negedge clk_sys);
  if(dut.aec!==1'b1 || c16_addr!==a) $fatal(1,"CPU lost bus %h",a);
  if(wr) begin
   if(a==16'hfd16 && hannes_enabled) begin refreg=v|8'h3c; bankwrites=bankwrites+1; if(c16_cas!==1'b1) $fatal(1,"register CAS"); end
   else if(a[15:8]==8'hfd || a[15:8]==8'hfe || a==16'hff3e || a==16'hff3f || a[15:5]==11'h7f8) begin ignored=ignored+1; if(c16_cas!==1'b1) $fatal(1,"I/O CAS %h",a); end
   else begin if(c16_cas!==1'b0) $fatal(1,"RAM no CAS %h",a); refmem[{eb(a,1'b1),a}]=v; writes=writes+1; end
  end else begin
   if(dut.c16_data!==exp) $fatal(1,"CPU read %h reg=%h bank=%d got=%h expected=%h",a,refreg,c16_ram_bank,dut.c16_data,exp);
   reads=reads+1; if(!cs0 || !cs1) begin romreads=romreads+1; if(c16_cas!==1'b1) $fatal(1,"ROM CAS"); end
  end
  @(posedge clk_sys); @(negedge clk_sys); dut.cpu.cpu.stimulus_addr=16'h0200; dut.cpu.cpu.stimulus_read=1;
 end endtask
 task sel(input [7:0] v); begin cycle(16'hfd16,1,v,0); cycle(16'hfd16,0,0,v|8'h3c); end endtask
 task wr(input [15:0] a,input [7:0] v); begin cycle(a,1,v,0); end endtask
 task rd(input [15:0] a); begin cycle(a,0,0,refmem[{eb(a,1'b1),a}]); end endtask
 always @(negedge clk_sys) if(monitor && dut.mos8360.phicounter==15 && dut.aec===1'b0) begin
  if(ram_we!==1'b0 || c16_rnw!==1'b1) $fatal(1,"TED write");
  if(c16_ram_bank!==eb(c16_addr,1'b0)) $fatal(1,"TED bank mismatch %h",c16_addr);
  if(c16_cas===1'b0 && cs0===1'b1 && cs1===1'b1) begin
   if(ram_dout!==refmem[{eb(c16_addr,1'b0),c16_addr}]) $fatal(1,"TED data mismatch %h bank=%d got=%h expected=%h",c16_addr,c16_ram_bank,ram_dout,refmem[{eb(c16_addr,1'b0),c16_addr}]);
   tedreads=tedreads+1; if(c16_ram_bank!=3) tedextra=tedextra+1; else tedbase=tedbase+1;
  end
 end
 initial begin
  for(i=0;i<262144;i=i+1) refmem[i]=0;
  for(i=0;i<65536;i=i+1) begin @(negedge clk_sys); dl_addr=i; dl_data=(i>>8)^i; dl_wr=1; refmem[196608+i]=dl_data; end
  @(negedge clk_sys); dl_wr=0; reset=0; dut.resetcounter=1000000;
  repeat(64) @(negedge clk_sys); monitor=1;
  cycle(16'hfd16,0,0,8'hff); wr(16'hff3f,0);
  for(b=0;b<4;b=b+1) begin sel(8'h7c|b); wr(16'h0fff,8'h79); wr(16'h1000,8'h10+b); wr(16'h3fff,8'h30+b); wr(16'h4000,8'h40+b); wr(16'h8000,8'h80+b); wr(16'hfcff,8'hc0+b); wr(16'hffff,8'hf0+b); end
  for(b=0;b<4;b=b+1) begin sel(8'h7c|b); rd(16'h0fff); rd(16'h1000); rd(16'h3fff); rd(16'h4000); rd(16'h8000); rd(16'hfcff); rd(16'hffff); sel(8'hfc|b); rd(16'h1000); rd(16'h3fff); rd(16'h4000); end
  sel(8'h7d); wr(16'hff3e,0); cycle(16'h8000,0,0,8'ha5); wr(16'h8000,8'h62); cycle(16'h8000,0,0,8'ha5); wr(16'hff3f,0); rd(16'h8000);
  wr(16'hff14,8'h40); wr(16'hff13,8'h42); wr(16'hff06,8'h1b); wr(16'hff07,8'h08);
  $display("Display config complete at %0t",$time); sel(8'h7c); repeat(150000) @(negedge clk_sys); sel(8'h3c); repeat(150000) @(negedge clk_sys);
  $display("Display reads %0d extension %0d base %0d",tedreads,tedextra,tedbase); for(p=0;p<1024;p=p+1) begin sel(8'h7c|(p%4)); wr(16'h5000+(((p/4)*73)%4096),p^(p>>8)); rd(16'h5000+(((p/4)*73)%4096)); end
  for(p=0;p<1024;p=p+1) begin sel(8'h7c|(p%4)); rd(16'h5000+(((p/4)*73)%4096)); end
  sel(8'h7c); @(negedge clk_sys); dl_addr=16'h6000; dl_data=8'hd7; dl_wr=1; @(negedge clk_sys); dl_wr=0; refmem[196608+16'h6000]=8'hd7;
  rd(16'h6000); sel(8'h7f); rd(16'h6000);
  sel(8'h7d); @(negedge clk_sys); reset=1; refreg=8'hff; repeat(32) @(negedge clk_sys); reset=0; dut.resetcounter=1000000;
  repeat(64) @(negedge clk_sys); cycle(16'hfd16,0,0,8'hff);
  hannes_enabled=0; repeat(32) @(negedge clk_sys); wr(16'hff3f,0); rd(16'h6000); cycle(16'hfd16,0,0,8'hfb); wr(16'hfd16,8'h00); rd(16'h6000);
  if(tedextra==0 || tedbase==0 || romreads==0) $fatal(1,"missing coverage TED/ROM");
  $display("PASS H005 (TVMODE=%b): CPU reads=%0d RAM writes=%0d register writes=%0d I/O writes=%0d ROM reads=%0d TED RAM reads=%0d (extension=%0d base=%0d)",TVMODE,reads,writes,bankwrites,ignored,romreads,tedreads,tedextra,tedbase); $finish;
 end
 initial begin #15000000; $fatal(1,"timeout"); end
endmodule
