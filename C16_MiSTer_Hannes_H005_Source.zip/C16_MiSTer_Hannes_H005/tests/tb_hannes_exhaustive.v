`timescale 1ns / 1ps
// H004: exhaustive map of all effective register configurations and both bus owners.
module tb_hannes_exhaustive;
reg clk=0, reset=1, enabled=1, cpu=1, mux=1, rnw=1;
reg [15:0] addr=0;
reg [7:0] din=0;
wire [7:0] dout;
wire [1:0] bank;
integer b, t, lim, own, a, n=0, legacy=0;
reg [7:0] val;
reg [1:0] expected;
always #5 clk=~clk;
hannes256 dut(clk,reset,enabled,cpu,mux,rnw,addr,din,dout,bank);
task tick; begin @(posedge clk); #1; end endtask
task wr(input [7:0] v); begin
    @(negedge clk); cpu=1; addr=16'hfd16; din=v; rnw=0; mux=1; tick;
    mux=0; tick; mux=1; rnw=1; tick;
    if(dout!==(v|8'h3c)) $fatal(1,"register readback %h",v);
end endtask
initial begin
    tick; reset=0;
    for(lim=0;lim<2;lim=lim+1) for(t=0;t<2;t=t+1) for(b=0;b<4;b=b+1) begin
        val=(lim<<7)|(t<<6)|b;
        wr(val);
        for(own=0;own<2;own=own+1) begin
            cpu=own;
            for(a=0;a<65536;a=a+1) begin
                addr=a; #1;
                expected=((a/4096 >= (lim ? 4 : 1)) && (own || t)) ? b : 3;
                if(bank!==expected) $fatal(1,"map reg=%h addr=%h owner=%d",val,addr,own);
                if(dout!==((own && a==16'hfd16) ? (val|8'h3c) : 8'hff))
                    $fatal(1,"data bus reg=%h addr=%h owner=%d",val,addr,own);
                n=n+1;
            end
        end
    end
    enabled=0; tick;
    for(own=0;own<2;own=own+1) begin
        cpu=own;
        for(a=0;a<65536;a=a+1) begin
            addr=a; #1;
            if(bank!==2'd3 || dout!==8'hff) $fatal(1,"legacy mode addr=%h owner=%d",addr,own);
            legacy=legacy+1;
        end
    end
    // Writing once on MUX falling edge: changing data while MUX remains low must not latch.
    enabled=1; wr(8'h7c); @(negedge clk); rnw=0; mux=1; din=8'hbd; tick;
    mux=0; tick; din=8'hff; repeat(10) tick; rnw=1; #1;
    if(dout!==8'hbd) $fatal(1,"register relatched during same bus cycle");
    mux=1; rnw=0; din=8'h7e; repeat(10) tick; rnw=1; #1;
    if(dout!==8'hbd) $fatal(1,"register wrote without falling MUX");
    wr(8'h7e); reset=1; tick; reset=0; #1;
    if(dout!==8'hff || bank!==2'd3) $fatal(1,"reset failed");
    $display("PASS: %0d enabled + %0d disabled full-address/owner checks; bus-cycle latching and reset",n,legacy);
    $finish;
end
endmodule
