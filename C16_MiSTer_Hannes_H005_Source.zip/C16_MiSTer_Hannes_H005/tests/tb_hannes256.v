`timescale 1ns / 1ps
module tb_hannes256;
reg clk=0, reset=1, enabled=0, cpu=1, mux=1, rnw=1;
reg [15:0] addr=0;
reg [7:0] din=0;
wire [7:0] dout;
wire [1:0] bank;
integer v, a, owner, n, j;
reg [15:0] probes [0:7];
reg [1:0] expected;
reg [7:0] mem [0:262143];
always #5 clk=~clk;
hannes256 dut(clk,reset,enabled,cpu,mux,rnw,addr,din,dout,bank);
task tick; begin @(posedge clk); #1; end endtask
task wr;
input [15:0] target;
input [7:0] value;
begin
    addr=target; din=value; rnw=0; mux=1; tick;
    mux=0; tick; mux=1; tick; rnw=1; #1;
end
endtask
task check_bank;
input [1:0] b;
begin #1; if(bank !== b) $fatal(1,"bank mismatch at %h: %d != %d",addr,bank,b); end
endtask
initial begin
    probes[0]=0; probes[1]=16'h0fff; probes[2]=16'h1000;
    probes[3]=16'h3fff; probes[4]=16'h4000; probes[5]=16'h8000;
    probes[6]=16'hfcff; probes[7]=16'hffff;
    tick; reset=0; addr=16'h8000; check_bank(3);
    wr(16'hfd16,0); if(dout!==8'hff) $fatal(1,"disabled IO");
    check_bank(3);
    enabled=1; tick; addr=16'hfd16; #1;
    if(dout!==8'hff) $fatal(1,"reset value");
    for(v=0;v<256;v=v+1) begin
        cpu=1; wr(16'hfd16,v[7:0]);
        if(dout !== (v[7:0] | 8'h3c)) $fatal(1,"readback %h",v);
        for(owner=0;owner<2;owner=owner+1) begin
            cpu=owner[0];
            for(a=0;a<8;a=a+1) begin
                addr=probes[a];
                if (addr < (v[7] ? 16'h4000 : 16'h1000) || (!cpu && !v[6])) expected=3;
                else expected=v[1:0];
                check_bank(expected);
                if(dout!==8'hff) $fatal(1,"unexpected IO response");
            end
        end
    end
    cpu=1; wr(16'hfd16,8'h7c); wr(16'hfd15,8'hff); addr=16'hfd16; #1;
    if(dout!==8'h7c) $fatal(1,"wrong address write");
    cpu=0; wr(16'hfd16,8'hff); if(dout!==8'hff) $fatal(1,"TED IO response");
    cpu=1; #1; if(dout!==8'h7c) $fatal(1,"TED changed register");
    // Distinct RAM signatures with an abstract memory array.
    for(n=0;n<4;n=n+1) begin
        wr(16'hfd16,8'h7c|n); addr=16'h4000; #1;
        mem[{bank,addr}]=8'h10+n;
        addr=16'h0200; #1; mem[{bank,addr}]=8'h55;
    end
    for(n=0;n<4;n=n+1) begin
        wr(16'hfd16,8'h7c|n); addr=16'h4000; #1;
        if(mem[{bank,addr}] !== (8'h10+n)) $fatal(1,"bank alias");
        addr=16'h0200; #1;
        if(mem[{bank,addr}] !== 8'h55) $fatal(1,"common RAM");
    end
    wr(16'hfd16,0); reset=1; tick; reset=0; addr=16'hfd16; #1;
    if(dout!==8'hff) $fatal(1,"reset did not restore FF");
    wr(16'hfd16,0); enabled=0; tick; check_bank(3);
    enabled=1; tick; if(dout!==8'hff) $fatal(1,"re-enable reset");
    $display("PASS: Hannes register, bank mapping, TED, reset and RAM signatures");
    $finish;
end
endmodule
