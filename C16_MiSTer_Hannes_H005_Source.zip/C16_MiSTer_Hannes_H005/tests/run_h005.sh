#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
tmp=$(mktemp -d)
trap 'rm -rf "$tmp"' EXIT
python3 tests/extract_h005_glue.py "$tmp/h005_glue.vh"
for mode in 1 2; do
  iverilog -g2012 -I"$tmp" -s tb_hannes_ted_bus -Ptb_hannes_ted_bus.TVMODE=$mode -o "$tmp/ted" \
    rtl/c16.v rtl/ted.v rtl/mos8501.v rtl/colors_to_rgb.v rtl/c16_keymatrix.v rtl/mos6529.v rtl/sid_card.v \
    rtl/iec_drive/iecdrv_misc.sv rtl/hannes256.v rtl/hannes_ram.v tests/gen_dpram_model.v tests/h005_stubs.v tests/tb_hannes_ted_bus.v
  vvp "$tmp/ted"
done
