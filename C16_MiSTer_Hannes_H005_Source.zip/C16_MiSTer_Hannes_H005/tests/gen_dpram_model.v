// Test-only behavioral replacement for the Quartus VHDL RAM. Never synthesize.
module gen_dpram #(parameter AW=16, DW=8) (
    input clock_a, clock_b,
    input [AW-1:0] address_a,address_b,
    input [DW-1:0] data_a,data_b,
    input wren_a,wren_b,cs_b,
    output [DW-1:0] q_b
);
    reg [DW-1:0] mem [0:(1<<AW)-1];
    reg [DW-1:0] q;
    always @(posedge clock_a) if(wren_a) mem[address_a]<=data_a;
    always @(posedge clock_b) begin
        if(wren_b) begin mem[address_b]<=data_b; q<=data_b; end
        else q<=mem[address_b];
    end
    assign q_b=cs_b?q:{DW{1'b1}};
endmodule
