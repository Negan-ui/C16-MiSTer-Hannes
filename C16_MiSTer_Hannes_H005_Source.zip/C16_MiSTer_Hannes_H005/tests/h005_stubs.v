// Test-only CPU bus driver, not a 6502 instruction emulator.
module T65(input [1:0] Mode,input Res_n,Enable,Clk,Rdy,Abort_n,IRQ_n,NMI_n,SO_n,output R_W_n,output [23:0] A,input [7:0] DI,output [7:0] DO);
 reg [15:0] stimulus_addr=16'h0200; reg [7:0] stimulus_data=0; reg stimulus_read=1;
 assign A={8'h00,stimulus_addr}; assign DO=stimulus_data; assign R_W_n=stimulus_read;
endmodule
module sid_top(input reset,clk,ce_1m,input [1:0] cs,input we,input [4:0] addr,input [7:0] data_in,output [7:0] data_out,input [12:0] fc_offset_l,fc_offset_r,input [17:0] ext_in_l,ext_in_r,output [17:0] audio_l,audio_r,input [1:0] filter_en,mode,input [3:0] cfg,input ld_clk,input [11:0] ld_addr,input [15:0] ld_data,input ld_wr);
 assign data_out=8'hff; assign audio_l=0; assign audio_r=0;
endmodule
