from pathlib import Path
import sys
s=Path('C16.sv').read_text()
Path(sys.argv[1]).write_text(s[s.index('wire [7:0] ram_dout;'):s.index('/////////////////   ROM')]+s[s.index('wire [7:0] cass_dout;'):s.index('reg        tap_rd;')])
