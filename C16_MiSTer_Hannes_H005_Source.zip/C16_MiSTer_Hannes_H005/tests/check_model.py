#!/usr/bin/env python3
"""Independent behavioral/address-map checks. This is NOT HDL simulation."""
from pathlib import Path
from hashlib import sha256
root = Path(__file__).resolve().parent.parent
# Model of physical banking and separate standard loader port.
class Memory:
    def __init__(self):
        self.standard = bytearray(65536)
        self.extra = [bytearray(61440) for _ in range(3)]
        self.reg = 255
        self.enabled = True
    def location(self, a, cpu=True):
        b = self.reg & 3
        if (not self.enabled or a < (0x4000 if self.reg & 128 else 0x1000)
                or (not cpu and not self.reg & 64) or b == 3):
            return self.standard,a
        return self.extra[b],a-0x1000
    def write(self,a,v):
        buf,off=self.location(a); buf[off]=v
    def read(self,a,cpu=True):
        buf,off=self.location(a,cpu); return buf[off]
    def select(self,v): self.reg=(v|0x3c) if self.enabled else 255
m=Memory()
# Independent specification: construct the 16-bit address regions from pages.
# Check every byte in every documented register setting (16 effective states).
checks=0
for v in range(256):
    m.select(v)
    assert m.reg == v|0x3c
    for cpu in (False,True):
        # Bits 2..5 cannot change map; sample all addresses for 16 effective states.
        addresses=range(65536) if v & 0x3c == 0x3c else (0,4095,4096,16383,16384,65535)
        for a in addresses:
            first_switchable_page=4 if v & 128 else 1
            expected=(v%4 if (a//4096 >= first_switchable_page and (cpu or v&64)) else 3)
            buf,off=m.location(a,cpu)
            assert buf is (m.standard if expected==3 else m.extra[expected])
            assert off==(a if expected==3 else a-4096)
            checks+=1
print(f'PASS: {checks:,} address/owner/register mapping checks in reference model')
for shift in (0,8):
    for b in range(4):
        m.select(0x7c+b)
        for a in range(4096,65536): m.write(a,((a>>shift)^b*53)&255)
    for b in range(4):
        m.select(0x7c+b)
        for a in range(4096,65536): assert m.read(a)==((a>>shift)^b*53)&255
print('PASS: 491,520 memory read comparisons across four banks and two address patterns (model)')
for b in range(4):
    m.select(0x7c+b); assert m.read(0x0fff)==0
    m.write(0x0200,0x55)
    m.select(0xbc+b); assert m.read(0x0200)==0x55
    assert m.read(0x1000)==m.standard[0x1000]
    assert m.read(0x4000,False)==m.standard[0x4000]
    m.select(0xfc+b); assert m.read(0x4000,False)==m.read(0x4000)
m.select(0xfc); m.standard[0x5000]=0xc7
assert m.read(0x5000)!=0xc7
m.select(255); assert m.read(0x5000)==0xc7
m.enabled=False; m.select(0); assert m.read(0x5000)==0xc7
print('PASS: shared RAM, TED override, standard-only loader and disabled mode (model)')
# Structural integration checks against actual delivered HDL files.
sv=(root/'C16.sv').read_text(); ram=(root/'rtl/hannes_ram.v').read_text(); ctl=(root/'rtl/hannes256.v').read_text(); qip=(root/'files.qip').read_text()
for fragment in ('O[50],RAM,64 KiB,256 KiB (Hannes);','hannes_enabled <= status[50];','hannes_ram main_ram','.cs(~c16_cas & cs0 & cs1)','.load_addr(dl_addr)', '.bank(c16_ram_bank)'):
    assert fragment in sv, fragment
for fragment in ('gen_dpram #(16) standard_ram','mem [0:61439]','addr - 16\'h1000','bank == BANK_ID','we && standard_sel','!cs ? 8\'hff'):
    assert fragment in ram,fragment
assert 'rtl/hannes_ram.v' in qip and 'rtl/hannes256.v' in qip
for fragment in ("addr == 16'hfd16",'old_mux && !mux && selected && !rnw',"4'b1111",'!cpu_owns_bus && !ted_follows'):
    assert fragment in ctl,fragment
for name in ('C16.sv','rtl/hannes_ram.v','rtl/hannes256.v','rtl/c16.v','files.qip'):
    print(sha256((root/name).read_bytes()).hexdigest(),name)
print('PASS: source integration markers; NOT compilation or HDL equivalence')
