#!/usr/bin/env python3
"""Execute the actual generated 6502 opcodes in a small instruction-level model.
Not a C16 emulator, no TED or KERNAL timing. Inject faults to verify diagnostics.
"""
from pathlib import Path
p=Path(__file__).parent
code=(p/'hannes_boundary_machine.bin').read_bytes()
symbols={k:int(v[1:],16) for k,v in (x.split(' = ') for x in (p/'hannes_boundary_symbols.txt').read_text().splitlines())}
def run(fault):
    mem=[bytearray(65536) for _ in range(4)]; mem[3][0x333:0x333+len(code)]=code; mem[3][0x1000]=0x42
    reg=255; pc=0x333; a=y=0; z=False; stack=[]; interrupt=False
    def bank(addr):
        limit=0x4000 if (reg&128 or fault=='boundary_stuck_high') and fault!='boundary_stuck_low' else 0x1000
        return 3 if addr<limit or fault=='alias' else reg&3
    def read(addr):
        if addr==0xfd16: return (reg|60)&(251 if fault=='cassette' else 255) if fault!='disabled' else 255
        return mem[bank(addr)][addr]
    def write(addr,v):
        nonlocal reg
        if addr==0xfd16:
            if fault!='disabled':reg=v|60
        else:mem[bank(addr)][addr]=v
    def fetch():
        nonlocal pc
        v=read(pc);pc+=1;return v
    def word(): return fetch()|fetch()<<8
    for n in range(5000):
        op=fetch()
        if op==0x08: stack.append(interrupt)
        elif op==0x78: interrupt=True
        elif op==0x28: interrupt=stack.pop()
        elif op==0xa9: a=fetch();z=a==0
        elif op==0xa0: y=fetch();z=y==0
        elif op==0x98: a=y;z=a==0
        elif op==0x09: a|=fetch();z=a==0
        elif op==0x49: a^=fetch();z=a==0
        elif op==0x8d: write(word(),a)
        elif op==0xad: a=read(word());z=a==0
        elif op==0xcd: z=a==read(word())
        elif op==0xc0: z=y==fetch()
        elif op==0xc8: y=(y+1)&255;z=y==0
        elif op==0xee:
            addr=word();v=(read(addr)+1)&255;write(addr,v);z=v==0
        elif op in (0xf0,0xd0):
            d=fetch();d=d-256 if d>=128 else d
            if z==(op==0xf0): pc+=d
        elif op==0x4c: pc=word()
        elif op==0x60:
            assert reg==255 and not interrupt and not stack and mem[3][0x1000]==0x42
            return mem[3][symbols['result']],n+1
        else: raise ValueError(hex(op),hex(pc-1))
    raise RuntimeError('did not return')
for fault,expected in [(None,0),('disabled',1),('cassette',1),('alias',2),('boundary_stuck_high',2),('boundary_stuck_low',3)]:
    actual,steps=run(fault);assert actual==expected,(fault,actual,expected)
    print(f'PASS: {fault or "normal"}: diagnostic result {actual}, {steps} instructions')
