# H002 — Hannes 256 KiB memory layout and validation harness

Base: H001, derived from the supplied C16_MiSTer source archive. H001 is preserved separately. This is an experimental source release, not a tested RBF.

## Changes

- The stock 64 KiB dual-port `gen_dpram` is reinstated as the standard bank (bank 3). Its PRG-loader port retains the original 16-bit addressing.
- Three independent, synchronous single-port M10K-targeted RAM arrays provide the switchable ranges of banks 0–2. Each stores $1000–$FFFF (60 KiB). Addresses below $1000 always go to bank 3; allocating another 4 KiB per extension bank is unnecessary. Initial contents are zero, as in the original RAM configuration.
- The logical Hannes configuration remains 256 KiB nominal (four 64 KiB banks); the physical backing storage in this implementation is 244 KiB, with the three unreachable low 4 KiB regions omitted. I/O and ROM overlays further restrict software-visible access in the usual way. No 320 KiB or CSORY mode is added.
- Raw main RAM storage drops from 2,097,152 bits in H001 to 1,998,848 bits in H002, a reduction of 98,304 bits (12 KiB). This is an RTL capacity calculation, **not** a measured Quartus M10K utilization result. The actual packing, timing and fit are unknown.
- `hannes256.v`, TED, CPU, SID and disk-drive implementations are unchanged from H001. The existing CAS/ROM gating is retained. The new RAM wrapper returns $FF when its output is not selected, maintaining the wired-AND bus convention. The PRG loader writes bank 3 even when another bank is selected; reset before direct PRG loading.

## Register and use

OSD: select `RAM: 256 KiB (Hannes)`, then `Reset & Apply`. The default 64 KiB mode is retained. $FD16 resets to $FF; bits 1:0 choose bank, bits 5:2 read high, bit 6 controls TED bank selection, bit 7 chooses the $1000/$4000 boundary. With bit 6 clear, TED reads bank 3 even if CPU accesses another bank. References: https://github.com/SukkoPera/Hannes256#programming and https://plus4world.com/hardware/256K_RAM_Hannes . H001's description of these bits is still applicable.

## Verification performed in this environment

- `python3 tests/check_model.py`: PASS, 2,100,032 reference-model address/owner/register mapping comparisons; 491,520 model memory read comparisons across four banks with separate low/high address patterns; shared RAM, TED, loader and disabled-mode checks; static source integration marker checks. See `tests/H002_model_results.txt`.
- `python3 tests/make_basic_test.py`: PASS, generated 326-byte BASIC PRG, linked-line pointers verified. Not executed on a C16.
- `sh tests/run.sh`: attempted, failed with exit 127 (iverilog unavailable). The second HDL testbench instantiates the actual Hannes controller and actual RAM wrapper, with a test-only behavioral VHDL RAM substitute. It writes and reads all switchable locations with both address patterns, checks shared RAM, TED override, loader isolation, CS gating and reset. These HDL tests are supplied, **not executed**.
- `sh build_h002.sh`: attempted, failed with exit 127 (Quartus not installed). Downloading a simulator package was also unsuccessful. No synthesis, fitter, timing, emulator or physical MiSTer results are available.

Model checks validate the intended design, not the Verilog implementation or actual bus timing. In particular the inferred 60 KiB memories and mixed-language wrapper must be checked with Quartus and on hardware.

## Build and acceptance

Use Quartus Prime Standard 17.0.2 with Cyclone V support (upstream C16.qsf toolchain). From this directory run `sh build_h002.sh`; optionally install Icarus Verilog first to execute the isolated HDL testbenches. On Windows run `quartus_sh --flow compile C16` in the Quartus command shell. Review the fitter report for M10K/ALM consumption and STA setup/hold results. The script copies the resulting RBF to `output_files/C16_Hannes_H002.rbf` after a successful compile. It does not certify timing. Do not replace the known-working core before hardware tests.

Hardware acceptance sequence:
1. Cold boot both C16 and Plus/4 in 64 KiB mode; test BASIC, disk loading and direct PRG loading, TED video and SID audio.
2. Enable Hannes, reset, verify PEEK(64790)=255. Run `tests/hannes_bank_test.prg` from a fresh BASIC session; expected `PASS: FOUR BANKS`.
3. Run the full memory test referenced by SukkoPera, then check both switching boundaries and TED selection on actual MiSTer hardware. Reset must restore bank 3 without clearing RAM.
4. Run Future World, Dream World and additional Hannes software; check PAL/NTSC, IEC disk and direct PRG loader. Check behavior when disabling the extension and resetting. Release only after these gates pass.

Original GPL licence and upstream authors' notices are retained. H001's document remains as historical information; H002 supersedes its RAM layout and test status. No upstream historical RBF files are included.
