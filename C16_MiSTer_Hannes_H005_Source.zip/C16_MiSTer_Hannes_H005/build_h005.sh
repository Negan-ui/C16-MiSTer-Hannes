#!/bin/sh
# Experimental candidate build. Requires Quartus 17.0.2/Cyclone V.
set -eu
cd "$(dirname "$0")"
case "${1:-}" in ''|--skip-hdl) ;; *) echo 'Usage: sh build_h005.sh [--skip-hdl]' >&2; exit 2;; esac
mkdir -p h005_build
python3 tests/check_model.py > h005_build/model.log
python3 tests/check_io_model.py >> h005_build/model.log
python3 tests/make_boundary_test.py > h005_build/diagnostic.log
python3 tests/check_boundary_machine.py >> h005_build/diagnostic.log
if [ "${1:-}" != --skip-hdl ]; then
  command -v iverilog >/dev/null && command -v vvp >/dev/null || { echo 'Icarus Verilog missing; install it or explicitly pass --skip-hdl.' >&2; exit 127; }
  if ! (sh tests/run.sh && sh tests/run_h005.sh) > h005_build/hdl.log 2>&1; then cat h005_build/hdl.log >&2; exit 1; fi
else
  printf 'HDL simulation explicitly skipped; not a verified release.\n' > h005_build/hdl.log
fi
command -v quartus_sh >/dev/null || { echo 'Quartus not installed; no candidate RBF generated.' >&2; exit 127; }
quartus_sh --version > h005_build/quartus_version.log
# No stale RBF can be promoted as this run's result. Leave unrelated files intact.
rm -f output_files/C16.rbf h005_build/C16_Hannes_H005_candidate.rbf h005_build/SHA256SUMS
if ! quartus_sh --flow compile C16 > h005_build/compile.log 2>&1; then tail -60 h005_build/compile.log >&2; exit 1; fi
[ -s output_files/C16.rbf ] || { echo 'No new RBF produced.' >&2; exit 1; }
for suffix in fit.rpt sta.rpt; do
  [ -s "output_files/C16.$suffix" ] || { echo "Missing C16.$suffix; candidate withheld." >&2; exit 1; }
  cp "output_files/C16.$suffix" h005_build/
done
cp output_files/C16.rbf h005_build/C16_Hannes_H005_candidate.rbf
(cd h005_build && sha256sum C16_Hannes_H005_candidate.rbf > SHA256SUMS)
printf '%s\n' 'Candidate only: inspect fitter, setup/hold timing and hardware results before release.'
