# H005 — TED-integrated bus stress tests

Base H004. All files from H004 are byte-identical; additions are testbenches, scripts and documentation. No changes to production RTL or Quartus project. Icarus Verilog 12.0 from the user-provided Debian package was used. No binaries of the simulator are redistributed.

## Results (actual HDL simulation)

| Checks | PAL | NTSC |
|---|---:|---:|
| CPU reads | 4164 | 4164 |
| CPU RAM writes | 1053 | 1053 |
| FD16 register writes | 2066 | 2066 |
| I/O writes without RAM CAS | 9 | 9 |
| ROM reads (subset of CPU reads) | 2 | 2 |
| TED RAM read comparisons | 16662 | 17936 |
| TED extension-bank reads | 10152 | 11106 |
| TED standard-bank reads | 6510 | 6830 |

Both simulations passed (exit 0). The original four H004 testbenches were rerun and passed (exit 0). Logs: `tests/H005_ted_bus_results.txt`, `tests/H005_regression_results.txt`.

The test runs the actual TED, C16 motherboard, MOS8501 wrapper, Hannes controller, extension RAM, SID-card address decoder, and keyboard glue. The RAM/CAS and cassette decode logic is extracted verbatim from C16.sv by `tests/extract_h005_glue.py`. A separate scoreboard verifies RAM reads and bank selections. No TED clock, AEC, MUX, CAS or TED address is forced. Both 4 KiB/16 KiB common boundaries, register readback, 256 shared logical addresses with different signatures in each of four banks, display fetches, TED override, ROM overlay, writes beneath ROM, I/O isolation, loader port, reset and disabled mode are exercised. The stimulus driver waits for CPU ownership and sets bus data before the actual falling MUX edge. The reset counter is shortened solely to avoid long reset delays; full reset duration is not tested.

## Limitations

T65 is replaced with a controlled bus stimulus driver (no 6502 instruction execution). SID audio is stubbed; standard RAM uses the existing behavioral replacement for the Quartus VHDL RAM. ROM read data is synthetic and the full MiSTer top-level, drive logic, OSD, PRG file loading sequence, analog/video/audio output are not simulated. The loader write port is tested, not the full loader state machine. The tests exercise actual TED video-standard timing logic in both modes with the same simulation clock, not physical PAL/NTSC clock frequencies. Icarus reports pre-existing MOS8501-to-T65 port-width warnings (unsized constants and 24-bit T65 address truncated to 16 bits by the wrapper); these are not synthesis results. No physical timing closure or complete software compatibility is claimed. Quartus is absent; no RBF generated. No full-core or MiSTer hardware test.

## Reproduce

Run `sh tests/run.sh` for original tests, then `sh tests/run_h005.sh` for both integrated tests with Icarus Verilog 12.0 and Python 3. The build script `sh build_h005.sh` runs these before invoking Quartus 17.0.2 with Cyclone V support; script syntax checked but Quartus build not run here. The next milestone is the actual Quartus compile and timing/resource review, then a hardware candidate, not a release. Keep original core available.
