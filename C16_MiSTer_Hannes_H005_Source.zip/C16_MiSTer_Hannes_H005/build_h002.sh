#!/bin/sh
# Run on a machine with Quartus Prime Standard 17.0.2 + Cyclone V support.
set -eu
cd "$(dirname "$0")"
command -v quartus_sh >/dev/null || { echo 'Quartus not installed; no RBF generated.' >&2; exit 127; }
if command -v iverilog >/dev/null && command -v vvp >/dev/null; then
    sh tests/run.sh
else
    echo 'Icarus Verilog unavailable; HDL tests skipped.' >&2
fi
quartus_sh --flow compile C16
[ -s output_files/C16.rbf ] || { echo 'No RBF produced.' >&2; exit 1; }
cp output_files/C16.rbf output_files/C16_Hannes_H002.rbf
printf '%s\n' 'Review fitter and timing reports before hardware use.'
