`timescale 1ns / 1ps
// Hannes-compatible 256 KiB bank controller for the MiSTer C16 core.
// SPDX-License-Identifier: GPL-3.0-or-later
// Register $FD16: [7] boundary, [6] TED follows bank, [1:0] bank.
// Unimplemented bits [5:2] read high. No CSORY or larger Hannes mode.
module hannes256 (
    input        clk,
    input        reset,
    input        enabled,
    input        cpu_owns_bus,
    input        mux,
    input        rnw,
    input [15:0] addr,
    input [7:0]  data_in,
    output [7:0] data_out,
    output [1:0] ram_bank
);
    reg [1:0] bank = 2'b11;
    reg bound_16k = 1'b1;
    reg ted_follows = 1'b1;
    reg old_mux = 1'b1;

    wire selected = enabled && cpu_owns_bus && (addr == 16'hfd16);
    wire shared_region = bound_16k ? (addr < 16'h4000) : (addr < 16'h1000);

    // The motherboard latches its address at the falling MUX edge.
    // Like the existing ROM bank latch, sample once per bus cycle.
    always @(posedge clk) begin
        old_mux <= mux;
        if (reset || !enabled) begin
            bank <= 2'b11;
            bound_16k <= 1'b1;
            ted_follows <= 1'b1;
        end else if (old_mux && !mux && selected && !rnw) begin
            bank <= data_in[1:0];
            bound_16k <= data_in[7];
            ted_follows <= data_in[6];
        end
    end

    // Neutral value on the core's wired-AND data bus unless selected.
    assign data_out = (selected && rnw) ?
                      {bound_16k, ted_follows, 4'b1111, bank} : 8'hff;

    // All legacy accesses and all common-area accesses use bank 3.
    // TED ownership is independent of CPU read/write direction.
    assign ram_bank = (!enabled || shared_region ||
                       (!cpu_owns_bus && !ted_follows)) ? 2'b11 : bank;
endmodule

// H003: preserve the original mirror decoding when Hannes is disabled.
// With Hannes enabled only $FD10 belongs to the user port.
module hannes_cassette_decode (
    input enabled,
    input [15:0] addr,
    input sense,
    input adc_active,
    output [7:0] data_out
);
    wire selected = enabled ? (addr == 16'hfd10) : (addr[15:4] == 12'hfd1);
    assign data_out = {5'b11111, ~selected | (~adc_active & sense), 2'b11};
endmodule
