`timescale 1ns / 1ps
// SPDX-License-Identifier: GPL-3.0-or-later
// Three extension banks; the original 64 KiB RAM remains a separate DPRAM.
// The bottom 4 KiB is physically unreachable in extension banks.
module hannes_ram (
    input clk,
    input [1:0] bank,
    input [15:0] addr,
    input [7:0] data_in,
    input we,
    input cs,
    output [7:0] data_out,
    input [15:0] load_addr,
    input [7:0] load_data,
    input load_we
);
    wire [7:0] standard_q;
    wire extra_valid = addr >= 16'h1000;
    // Defensive fallback: any lower-area access goes to the standard RAM.
    wire standard_sel = (bank == 2'd3) || !extra_valid;
    wire [15:0] extra_addr = addr - 16'h1000;
    wire [7:0] extra_q [0:2];

    gen_dpram #(16) standard_ram (
        .clock_a(clk), .address_a(load_addr), .data_a(load_data), .wren_a(load_we),
        .clock_b(clk), .address_b(addr), .data_b(data_in),
        .wren_b(we && standard_sel), .q_b(standard_q), .cs_b(cs && standard_sel)
    );

    genvar i;
    generate for (i=0; i<3; i=i+1) begin : extension
        localparam [1:0] BANK_ID = i;
        (* ramstyle = "M10K" *) reg [7:0] mem [0:61439];
        reg [7:0] q;
        integer init_addr;
        initial begin
            for (init_addr=0; init_addr<61440; init_addr=init_addr+1)
                mem[init_addr] = 8'h00;
        end
        // Synchronous, write-first, as in the original gen_dpram.
        // Only the selected extension receives a write.
        always @(posedge clk) begin
            if (!standard_sel && bank == BANK_ID) begin
                if (we) begin
                    mem[extra_addr] <= data_in;
                    q <= data_in;
                end else begin
                    q <= mem[extra_addr];
                end
            end
        end
        assign extra_q[i] = q;
    end endgenerate

    assign data_out = !cs ? 8'hff : standard_sel ? standard_q : extra_q[bank];
endmodule
