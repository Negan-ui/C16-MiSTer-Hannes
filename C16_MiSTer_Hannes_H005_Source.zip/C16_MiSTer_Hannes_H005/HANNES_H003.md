# H003 — I/O integration correction and hardware diagnostics

Base: H002. This is an experimental source revision; no compiled RBF is supplied.

## Actual correction

H002 inherited the stock core's cassette sense mirror at $FD10–$FD1F. Its bit 2 is ANDed onto the common data bus. When sense is low or the ADC is active, the cassette peripheral drives $FB; therefore reading $FD16 could turn $FF into $FB, or clear bit 2 of any Hannes read. This is inconsistent with the selected Hannes register readback and can break detection. The hardware documentation describes decoding the user port at $FD10 when the Hannes extension is fitted.

H003 adds `hannes_cassette_decode` to `rtl/hannes256.v`, and instantiates it in `C16.sv`. Hannes mode now decodes cassette sense at $FD10 only. With Hannes disabled, the original $FD10–$FD1F mirror is retained exactly. The RAM controller, physical layout, CPU, TED, IEC and SID HDL are unchanged from H002. Reference: https://github.com/SukkoPera/Hannes256#technical-notes and https://plus4world.com/hardware/256K_RAM_Hannes . No hardware circuit source copied.

## Tests performed locally

- Re-ran H002 model tests: 2,100,032 address comparisons, 491,520 memory-read comparisons.
- New cassette I/O model: 525,312 checks, including all 65,536 addresses, all enable/sense/ADC combinations, and 1,024 Hannes-register readbacks. Reproduces the old wired-AND collision and checks the proposed mapping. Not HDL simulation.
- Added `tests/tb_hannes_io.v` to the existing HDL suite. It tests the actual new decoder and actual Hannes controller together; supplied but not executed.
- `tests/hannes_boundary_test.prg`: BASIC 3.5 launcher for 189 bytes of 6502 code in the cassette buffer $0333–$03EF (decimal 819–1007). With interrupts masked it switches banks safely below $1000. It writes distinct signatures into $1000, $3FFF, $4000, $7FFF in all four banks; verifies register readback, bank separation and both boundaries. Restores register to $FF, the original $1000 byte and interrupt status before returning. It is a targeted destructive test, not a full memory sweep. Use a fresh session, no important data and no tape activity. Other test locations are not restored; reset afterwards.
- Executed the actual generated opcodes in a small Python instruction model, not an emulator of the entire machine. Normal model returns 0; injected disabled mode and cassette collision return 1, bank alias and stuck-high boundary return 2, stuck-low boundary returns 3. BASIC token and pointer structure checked; BASIC execution and real KERNAL behavior still need testing.
- Quartus, Icarus Verilog and Docker/Podman are absent; package download failed due to DNS/network. No synthesis, HDL simulation, timing or MiSTer results. See test logs.

## Build on a suitable Linux x86-64 host

Install Quartus Prime 17.0.2 with Cyclone V support (project's configured version), Icarus Verilog, Python 3 and standard shell utilities. Add Quartus binaries to PATH. Run `sh build_h003.sh`. The script runs model and HDL tests first, captures logs and compiles `C16.qpf`. For an explicit experimental build without HDL simulation, pass `--skip-hdl`. It refuses to promote a stale RBF and requires fitter and STA reports to be present. The candidate output is `h003_build/C16_Hannes_H003_candidate.rbf` with SHA-256 and reports. Report presence does not establish timing closure. Inspect all setup/hold slack and unconstrained paths, and verify fit on 5CSEBA6U23I7. On Windows open `C16.qpf` in the same Quartus version and run the full compilation, then inspect reports and output_files/C16.rbf. General instructions: https://mister-devel.github.io/MkDocs_MiSTer/developer/mistercompile/ .

A 1024x8 M10K packing assumption gives about 244 M10K blocks for main RAM (64 standard + 180 extension), roughly 44% of 553 available M10Ks. This is a simple estimate, not a Quartus result; other core RAMs/ROMs and actual packing can change fit. No additional external SDRAM is required by the H002/H003 RTL design.

## Hardware acceptance procedure

1. Keep the original working core on the SD card. Load a separately named candidate, choose `RAM: 64 KiB`, `Reset & Apply`, boot and test PRG and disk loading, tape, keyboard, PAL/NTSC, TED and SID. Do not overwrite the stock core.
2. Select `RAM: 256 KiB (Hannes)`, `Reset & Apply`. From a fresh BASIC session, `PRINT PEEK(64790)` should print 255, including when cassette sense changes. Verify that $FD10 still behaves like the user-port cassette input. In normal mode $FD16 is not a Hannes register.
3. Load `tests/hannes_boundary_test.prg` using the OSD PRG loader or via IEC disk, then `RUN`. Expected `PASS: BOTH BOUNDARIES`. Failure code 1 = register readback, 2 = bank separation / $1000 boundary, 3 = $4000 boundary. Reset afterwards. Do not run while tape is playing. Run the supplied H002 BASIC bank test as another check.
4. Execute siz's full RAM test (linked from Hannes256 documentation); test TED bank selection and PAL/NTSC display, Dream World and Future World. Test games which use Hannes memory. Verify reset and switch back to 64 KiB.
5. Release only after synthesis, timing and physical tests. GPL notices and upstream credits retained.
