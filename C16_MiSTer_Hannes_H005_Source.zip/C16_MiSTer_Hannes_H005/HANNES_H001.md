# H001 — Experimental Hannes 256 KiB support

Base: supplied C16_MiSTer source archive, commit 25d9d74366a8ebd0059affa2d1de14f08722ae17.
The original authors, copyright notices and GPL licence are retained.

## Usage (after a successful Quartus build)

1. Load the newly built RBF on MiSTer. Open the OSD.
2. Choose `RAM: 256 KiB (Hannes)` and then `Reset & Apply`.
3. To revert, choose `64 KiB` and reset again. Both C16 and Plus/4 models are supported by the design.

## Hardware contract

* 256 KiB total RAM; four 64 KiB banks, bank 3 is the standard bank.
* $FD16 is read/write and resets to $FF. Bits 1:0 select bank. Bit 7 chooses the common area ($0000–$0FFF if clear, $0000–$3FFF if set). Bit 6 selects TED access: clear forces bank 3; set follows selected bank outside the common area. Bits 5:2 read as ones; writes to those bits are ignored. No CSORY mode or 512 KiB/1 MiB mode.
* Hannes is decoded only on CPU accesses to exactly $FD16. When disabled the register does not drive the data bus and every memory access uses bank 3.
* Existing RAM CE, CAS write strobes, ROMs and SID logic are unchanged. The CPU/TED AEC signal selects bus ownership. Register writes are sampled at the falling MUX transition, following the existing motherboard/SID timing convention.
* The direct MiSTer PRG loader always targets standard bank 3; it is intended for loading in the normal reset configuration, not for injecting data into a live alternate bank. Floppy/IEC software transfers use normal CPU banking.
* RAM changes from 64 KiB to 256 KiB inside FPGA block RAM; no SDRAM or DDRAM interface change. This adds 1,572,864 raw RAM bits (before FPGA block packing). Resource fit and timing must be checked in Quartus; they are not proven here.

References: original Hannes/Solder behavior described at https://plus4world.com/hardware/256K_RAM_Hannes and https://github.com/SukkoPera/Hannes256 (programming section). The implementation is original HDL based on the documented behavior, not copied board logic. VICE's Hannes emulation currently forces bit 6 high on readback and does not implement the TED selection there (https://raw.githubusercontent.com/VICE-Team/svn-mirror/master/vice/src/plus4/plus4memhannes256k.c); H001 intentionally targets the documented hardware feature instead.

## Changed files

- `C16.sv`: menu status bit 50, reset-latched enable, 18-bit dual-port RAM and loader bank selection.
- `rtl/c16.v`: bank controller integration and wired-AND I/O readback.
- `rtl/hannes256.v`: new bank controller.
- `files.qip`: register new Verilog source in both Quartus project revisions.
- `tests/`: standalone HDL testbench, BASIC diagnostic and generator.

## Build

Use the project's original Quartus Prime Standard 17.0.2 toolchain with Cyclone V device support. From this directory:

```sh
quartus_sh --flow compile C16
```

If synthesis, fitter and timing analysis succeed, inspect `output_files/C16.fit.rpt` and the STA reports; use `output_files/C16.rbf` (the existing QSF enables RBF generation). Rename a copy to `C16_Hannes_H001.rbf` for testing. Do not overwrite a working core. The alternate C16_Q13 project remains available as in upstream but is not tested.

## Verification and limitations

- `tests/run.sh` runs a self-checking Icarus Verilog testbench for all 256 register write values, eight boundary/address probes, both bus owners, readback, disabled mode, reset and distinct bank signatures. Requires iverilog and vvp. The testbench is supplied but was **not executed** in this environment: neither simulator nor Quartus is installed, and package installation failed because network DNS is unavailable.
- `tests/hannes_bank_test.prg`: load with a freshly reset machine, then RUN. Tests four independent banks at $4000/$5000, shared RAM at $3F00 and register readback in the $4000 boundary mode. This intentionally changes those RAM locations. Use only on a fresh BASIC session. PASS is expected in Hannes mode; FAIL in standard 64 KiB mode. PRG line chain checked programmatically, execution not tested.
- Hardware regression checklist: test 64 KiB BASIC boot and standard disk/PRG loads; both C16 and Plus/4; four-bank BASIC test; full siz memory test; Dream World / Future World; PAL/NTSC and SID; Hannes graphics with bit 6 clear and set; both boundary values; reset while another bank is selected; actual LittleSixteen-compatible software. Hardware tests and mixed-language core simulation remain outstanding.

This is an experimental source release, not a validated FPGA binary. The archive omits upstream historical RBF binaries to avoid any confusion with a new build.
