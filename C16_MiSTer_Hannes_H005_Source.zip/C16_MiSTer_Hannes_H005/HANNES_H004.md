# H004 — First executed HDL regression suite

Base: H003. Production RTL and Quartus project unchanged. Corrected an invalid mixed net declaration/assignment in `tests/tb_hannes_io.v`, expanded I/O coverage to the entire address space, and added `tests/tb_hannes_exhaustive.v` to `tests/run.sh`. The user-supplied Debian AMD64 Icarus Verilog 12.0 package was unpacked outside the project, and `iverilog` invoked with `-B` pointing at the extracted ivl directory. No simulator binaries are redistributed in this source archive.

## Actual HDL simulation results

All four testbenches compiled and ran successfully with Icarus Verilog 12.0. See `tests/H004_hdl_results.txt` for stdout.

- Register test: all 256 input bytes, both bus owners, boundary probes, wrong-address and TED write rejection, reset and bank signatures.
- RAM test: 491,552 read comparisons, including two complete passes over 4 x 60 KiB switchable range, shared area, TED override, loader and reset. Actual Hannes controller and extension RAM RTL; original vendor VHDL standard RAM replaced with a behavioral Verilog model for this test. Test directly drives RAM signals, not CPU instructions or TED-generated CAS cycles.
- I/O test: 525,312 checks of the actual Hannes register and cassette decoder, including all 65,536 addresses and 8 enable/sense/ADC combinations plus all 256 register writes in 4 combinations.
- Exhaustive controller test: 2,097,152 enabled and 131,072 disabled address/owner checks, readback/neutral wired-AND output, one write per falling MUX edge, reset. No checks of analog or FPGA timing.

Partial motherboard elaboration also passes in Icarus (`-i` intentionally ignores unresolved CPU T65 VHDL and SID top). See `tests/H004_elaboration.txt`. This is not a full core simulation or synthesis. The historical H001-H003 logs record the limitations at those revisions; H004 results supersede the earlier lack of a simulator.

## Reproduce

With Icarus Verilog 12.0 installed and `iverilog` and `vvp` on PATH, run `sh tests/run.sh` from the project root. No Quartus is needed for these four tests. `sh build_h004.sh` also runs the reference models and diagnostic checks, then requires Quartus 17.0.2 with Cyclone V support for a new candidate RBF. In the present environment all pre-build tests passed; the script stopped with exit 127 because Quartus is not installed. No RBF is included.

## Remaining validation

H005: integrated bus-cycle tests with actual TED timing, motherboard glue and realistic CPU bus stimulus, followed by additional RAM stress scenarios. Complete mixed-language simulation, Quartus fitter and timing closure, and actual MiSTer hardware testing remain necessary. No claim of physical compatibility or full software compatibility is made. Keep a working original core for fallback. See H003 notes for hardware acceptance and licensing.
